# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '37a8c8f77de9c96c36c63ed016d59071ea18bc1506854560e2bb9e41f5c9dd5eea3ed6bbb829c2c96969af8056d17077b6601c2ade19702e4249c4a74a734cc6'